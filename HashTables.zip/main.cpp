/*
Program Name: Hash Table
Date: 12/01/2023
Author: Pragnasri Vellanki
Module Purpose
This program analyzes data in the text file provided, creates a hash table for the names, and displays them.
 */

#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <unordered_map>
#include <string>

using namespace std;

// Defaults in solution folder
string inputFileNameStr = "namesids.txt";

//define namePair using C++  pair template class (2 strings - first & last name)
typedef pair<string, string> namePair;

//define stl::hash function for namePair keys
namespace std {

  template <> class hash <namePair> {
  public:
    size_t operator() (const namePair& namePair) const {
      return hash<string>() (namePair.first) ^ hash<string>() (namePair.second);
    }//size_t operator()
  };//class hash

}//namespace std


void displayHashTableLookupResult(pair<string, string> namePair, unordered_map<pair<string, string>, unsigned int>& hashTable) {
    
  //$$ use stringstream object to display lookup result
  //$$ display the result id or
  //$$ a message that indicates if there is not a entry in the hash table
    
    stringstream stringStreamObj;

    stringStreamObj << setw(20) << left << namePair.first << setw(20) << left << namePair.second;
    cout << stringStreamObj.str();
    if (hashTable[namePair])
        cout << setw(29) << left << hashTable[namePair] << endl;
    else
        cout << "There is not a hash table entry for this name pair" << endl;
  
 
};


int main(int argc, char* argv[]) {

  //define hashTable as namepair keys and integer value identifications (open address linear probe)
  unordered_map<namePair, unsigned int> hashTable;
    
  //Put in the hash table the namePair keys and associated number ids from text file
  ifstream inputFileStreamObj(inputFileNameStr);

  // $$ Check if file can be opened

    if (inputFileStreamObj.fail()) {
       cout << "File " << inputFileNameStr << "could not be opened !" << endl;
       cout << endl << "Press the enter key once or twice to leave..." << endl; cin.ignore(); cin.get();
       exit(EXIT_FAILURE);
     }

    
  // $$ read in to hash table namePair(firstName, lastname)] and set to id from file
    string firstName,lastName;
    unsigned int id;
    while(inputFileStreamObj >> firstName >> lastName >> id){
        hashTable[pair<string,string>(firstName,lastName)] = id;
    }
    
    
  
  // $$ range based for loop to display elements in the hash table map, namePair keys along with ids
    for (pair<pair<string, string>, unsigned int> element : hashTable) {
        cout << setw(10) << left << element.first.first;
        cout << setw(10) << left << element.first.second;
        cout << setw(10) << left << element.second << endl;
    }
    cout << endl << endl;
  //$$ look up 6 ids in hash table, 2 of each are not in the table
    displayHashTableLookupResult(pair<string, string>("Gal", "Varsano"), hashTable);
    displayHashTableLookupResult(pair<string, string>("Stephanie", "Clifford"), hashTable);
    displayHashTableLookupResult(pair<string, string>("Marion", "Morrison"), hashTable);
    displayHashTableLookupResult(pair<string, string>("Hillary", "Rodham"), hashTable);
    displayHashTableLookupResult(pair<string, string>("Pinkie", "Pie"), hashTable);
    displayHashTableLookupResult(pair<string, string>("Rainbow", "Dash"), hashTable);
  
  //$$ freeze screen with Press enter key once or twice to end code
    inputFileStreamObj.close();

    cout << "Press the enter key once or twice to end." << endl;
    cin.ignore();
    cin.get();

  return EXIT_SUCCESS;
}
