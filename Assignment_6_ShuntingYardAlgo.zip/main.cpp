/*
Program Name: Shunting Yard Post Fix BET
Date: 11/10/2023
Author: Pragnasri Vellanki
Module Purpose
This program uses the Shunting Yard Algorithm to sort through experssions.

*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <stack>

using namespace std;

string inputFileNameStr = "expressions.txt";                  // Default location in solution folder

class OperatorMapClass {

private:
  typedef map<char, int>    OperatorPrecedenceMapType;
  OperatorPrecedenceMapType operatorMapObj;

public:

  OperatorMapClass() {
    operatorMapObj.insert(OperatorPrecedenceMapType::value_type('+', 1));
    operatorMapObj.insert(OperatorPrecedenceMapType::value_type('-', 1));
    operatorMapObj.insert(OperatorPrecedenceMapType::value_type('/', 2));
    operatorMapObj.insert(OperatorPrecedenceMapType::value_type('*', 2));
  }//OperatorMapClass ()

  bool isStackOperatorHigherPrecedence(char operatorChar, char operatorStackChar) {
    return((operatorMapObj.count(operatorStackChar))
      &&
      (operatorMapObj.at(operatorStackChar) >= operatorMapObj.at(operatorChar)));
  }//isStackOperatorHigherPrecedence()

  bool  isOperator(char token) {
      if(operatorMapObj.count(token) == 0){
          return false;
      } else {
          return true;
      }
      // xxx check if token operator Map Object is 0 or not to return true or false
   
  }//isOperator()

};//OperatorMapClass

OperatorMapClass  operatorMapObj;

class ShuntingYardClass {

public:

  string createPostFixFrom(string infixString) {

    string       outputString;
    stack <char> operatorStackObj;
    cout << infixString << endl;
    
    int counter = 0;
    for (char token : infixString) {
      //cout << "kaka" << endl;
      counter++;
      //cout << counter << endl;
      //cout << token << endl;
      switch (token) {
      case '/': case '*': case '+': case '-':
        while(!operatorStackObj.empty() && operatorStackObj.top() != '(' && OperatorMapClass().isStackOperatorHigherPrecedence(token,operatorStackObj.top())){
            outputString += operatorStackObj.top();
            operatorStackObj.pop();
        }
        operatorStackObj.push(token);
              /*

         while (the stack is not empty
                  AND
                the top of the stack token is not a left parenthesis
                  AND
                precedence of the current operator <= precedence of the top of the stack token
               )
         {
              Push back the stack top token to the output string
              Pop the stack top and discard it
          }//while-end

           Push the current operator token onto the stack
        */
        break;
      case '(':                                                       // left parenthesis
          // xxx insert code here
        operatorStackObj.push('(');
          // push this token on the stack
        break;
      case ')':
        // xxx insert code here   // right parenthesis
        //cout << operatorStackObj.top() << endl;
        while(!operatorStackObj.empty() && operatorStackObj.top() != '('){
            //cout << "Inside the while loop" << endl;
            outputString += operatorStackObj.top();
            operatorStackObj.pop();
        }
        //cout << "Outside the while loop" << endl;
        operatorStackObj.pop();
        /*

        while (the stack is not empty AND the top stack token is not a left parenthesis)
        {
           Push back the stack top token to the output string
        }//while-end

        Pop the left parenthesis from the stack and discard it
        */
        break;
      default:                                                        // operand
          // xxx insert code here
        outputString += token;
        //cout << outputString << endl;
          // push back the operand symbol to the output string
        break;
      }//switch
    }//for
    //cout << outputString << endl;
    // xxx insert code here
    /*
     while (the stack is not empty)
     {
       //Push back any remaining stack tokens to the output string
    }//while-end
    */
      while(!operatorStackObj.empty()){
          outputString += operatorStackObj.top();
          operatorStackObj.pop();
      }
    return(outputString);

  }//postfix()

};//ShuntingYardClass



class TreeNodeClass {

public:
    TreeNodeClass* left;
    char            value;
    TreeNodeClass* right;

};//TreeNodeClass

TreeNodeClass* BuildNewNodeObjPtrMethod(char value) {
    // xxx new a new TreeNodeClass pointer
    // set value in new node and left and right pointers
    TreeNodeClass* newNode = new TreeNodeClass();
    newNode -> left = nullptr;
    newNode -> value = value;
    newNode-> right = nullptr;
    // return new node pointer

    return newNode; // dummy return
};


TreeNodeClass* ConstructBET(string postFixStr) {
    stack<TreeNodeClass*>   parseStack;
    TreeNodeClass*          newNodePtr;
    OperatorMapClass        OperatorMapObj;

    // xxx must develop code here
    // Process each character of the post-fix expression into token
    char token=' ';
    for(char token: postFixStr){
        // Form a new node pointer
        
        newNodePtr = BuildNewNodeObjPtrMethod(token);

        // check if an operator
        if(/*parseStack.size() > 1 && */operatorMapObj.isOperator(token))
        {
            // parse stack nodes into a new subtree as children
            // Save/Add this sub tree node to the stack
            newNodePtr-> right = parseStack.top();
            parseStack.pop();
            newNodePtr-> left = parseStack.top();
            parseStack.pop();
            parseStack.push(newNodePtr);

        }
        // not operator
        else {
            // operand, push node onto stack
            parseStack.push(newNodePtr);
        }
    }
    //  Place formed root node on the stack into tree
    return parseStack.top();
}

string buildString;

void preorder(TreeNodeClass* treeNode) {
    if(treeNode){
        buildString += treeNode -> value;
        preorder(treeNode->left);
        preorder(treeNode -> right);
    }
    //buildString += treeNode->value;
}

bool areParensRequired(TreeNodeClass* treeNode, char value) {
    OperatorMapClass operatorMapObj;
    if (operatorMapObj.isOperator(value) &&
        operatorMapObj.isOperator(treeNode->value) &&
        operatorMapObj.isStackOperatorHigherPrecedence(treeNode->value, value)) {
        buildString += '(';
        return true;
    }
    return false;
}

void inorder(TreeNodeClass* treeNode) {
    //xxx do in order transversal to build string
    bool parensRequired = false;
    TreeNodeClass* current = treeNode;
    if (treeNode) {
        parensRequired = areParensRequired(current->left, current->value);
        inorder(current->left);
        if(parensRequired){
            buildString += ')';
        }
        buildString += current -> value;
        parensRequired = areParensRequired(current->right, current->value);
        inorder(current -> right);
        if(parensRequired){
            buildString += ')';
        }
     
    }//if
}

void postorder(TreeNodeClass* treeNode) {
    //xxx do post order transversal to build string
    if(treeNode){
        postorder(treeNode->left);
        postorder(treeNode->right);
        buildString += treeNode -> value;
    }

    
}



int main() {

  ifstream  inputFileStreamObj(inputFileNameStr);

  if (inputFileStreamObj.fail()) {
    cout << "File could not be opened !" << endl;

    return (EXIT_FAILURE);
  }//if

  string  infixExpressionStr,
          postfixExpressionStr;

  ShuntingYardClass shuntingYardObj;

  while (inputFileStreamObj >> infixExpressionStr) {

      cout << "InFix   Expression : " << infixExpressionStr << endl;
      postfixExpressionStr = shuntingYardObj.createPostFixFrom(infixExpressionStr);
      //cout << "lala" << endl;
      cout << "PostFix Expression : " << postfixExpressionStr << endl << endl;
      TreeNodeClass* expressionTreeRootPtr = ConstructBET(postfixExpressionStr);
      buildString = "";  preorder(expressionTreeRootPtr);
      cout << "Tree  pre-order expression is " << endl << buildString << endl << endl;

      buildString = "";  inorder(expressionTreeRootPtr);
      cout << "Tree  in-order expression is " << endl << buildString << endl << endl;

      buildString = "";  postorder(expressionTreeRootPtr);
      cout << "Tree post-order expression is " << endl << buildString << endl << endl;

      cout << endl << endl;

  };//while

  inputFileStreamObj.close();

  cout << "Press the enter key once or twice to end." << endl;

  return EXIT_SUCCESS;

}//main()
